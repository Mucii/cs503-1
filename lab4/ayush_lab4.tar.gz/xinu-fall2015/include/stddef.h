/* stddef.h */

/* TEMPORARY */

/* Function declaration return types */
typedef void exchandler;        /**< exception procedure                */
typedef int message;            /**< message passing content            */
